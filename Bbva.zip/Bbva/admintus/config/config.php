<?php
/* PANEL CONFIGURATION */
define('PANEL_PASS', '1703');
/* DATABASE CONFIGURATION */
define('DB_HOST', 'localhost'); //puerto 3308, si no lo pongo parece que no funciona
define('DB_USER','root');
define('DB_PASS', '');
define('DB_NAME', 'test');
define('DB_TYPE', 'mysql');
define('DB_CHARSET', 'utf8');